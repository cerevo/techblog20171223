/*
 * main.c
 *
 * Created: 2017/12/07 21:40:14
 * Author : Ginya
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>


//--------------------------------------------------------------
// �R���y�AA�� Duty�V�[�P���X�p�����[�^
uint8_t		m_uiCompACnt = 0;				// CompA Interrput Count (for duty update interval)
uint8_t		m_uiSinDeg   = 0;				// Sin Degree
uint8_t		m_uiSinNum   = 0;				// Sin Table Num
uint8_t		m_uiSinSeq   = 0;				// Sin Table Sequence
uint16_t	m_uiWaitBlink = 0;	


//--------------------------------------------------------------
// 8bit PWM pulse �� Duty (���̈����T�C���e�[�u�����g��)
// TCCR0B��bit�����₷�Ƃ����Ɗ��炩�ɂȂ��Ċy������������Ȃ���I
const uint8_t	cnui8SinCountTbl[3][90] =
{
	{
		4,   9,   13,  18,  22,  27,  31,  35,  40,  44,
		49,  53,  57,  62,  66,  70,  75,  79,  83,  87,
		91,  96,  100, 104, 108, 112, 116, 120, 124, 127,
		131, 135, 139, 143, 146, 150, 153, 157, 160, 164,
		167, 171, 174, 177, 180, 183, 186, 190, 192, 195,
		198, 201, 204, 206, 209, 211, 214, 216, 219, 221,
		223, 225, 227, 229, 231, 233, 235, 236, 238, 240,
		241, 243, 244, 245, 246, 247, 248, 249, 250, 251,
		252, 253, 253, 254, 254, 254, 255, 255, 255, 255
	},
	{
	// ���ɂ��Ɍ���
		5,   7,   8,   9,   11,  13,  14,  17,  19,  25,
		50,  75,  100, 75,  50,  25,  17,  10,  15,  25,
		40,  70,  100, 126, 155, 170, 155, 126, 100, 70,
		30,  15,  8,   6,   5,   4,   5,   6,   8,   15,
		30,  70,  96,  130, 160, 210, 242, 252, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 254, 253, 251, 246, 241, 236, 231, 226,
		221, 216, 211, 205, 199, 192, 185, 180, 176, 173,
		170, 171, 174, 176, 182, 188, 192, 196, 198, 200
	},
	// ���sin�g�`
	{
		72,  74,  76,  79,  81,  83,  85,  88,  90,  92, 
		94,  96,  99,  101, 103, 105, 107, 109, 111, 114, 
		116, 118, 120, 122, 124, 126, 128, 130, 132, 134, 
		136, 138, 140, 141, 143, 145, 147, 149, 150, 152, 
		154, 156, 157, 159, 161, 162, 164, 165, 167, 168, 
		170, 171, 172, 174, 175, 176, 178, 179, 180, 181, 
		182, 184, 185, 186, 187, 188, 188, 189, 190, 191, 
		192, 193, 193, 194, 195, 195, 196, 196, 197, 197, 
		198, 198, 198, 199, 199, 199, 199, 199, 199, 200
	}
};


ISR (TIM0_COMPA_vect)
{
	//-----------------------------------------
	// Duty �X�V
	switch (m_uiSinSeq)
	{
	case 0:	// �ڂ�[���ƌ���
		if (m_uiCompACnt <= 15)
		{
			m_uiCompACnt++;
		}
		else
		{
			if (m_uiSinDeg < 89)
			{
				m_uiSinDeg++;
				m_uiSinNum++;
				
				OCR0AL = cnui8SinCountTbl[0][m_uiSinNum];
				OCR0BL = cnui8SinCountTbl[0][m_uiSinNum];
			}
			else	// m_uiSinDeg > 90
			{
				if (m_uiSinDeg < 179)
				{
					m_uiSinDeg++;
					m_uiSinNum--;
				}
				else
				{
					m_uiSinDeg = 0;
					m_uiSinNum = 0;
				}
				
				OCR0AL = cnui8SinCountTbl[0][m_uiSinNum];
				OCR0BL = cnui8SinCountTbl[0][m_uiSinNum];
			}
			
			// next sequence
			if (m_uiSinDeg >= 179)
			{
				m_uiSinDeg   = 0;				// Sin Degree
				m_uiSinNum   = 0;				// Sin Table Num
				m_uiSinSeq   = 1;				// �ꎟ�x��n�I�g�`
			}
			
			m_uiCompACnt = 0;
		}
		break;
		
	case 1:	// ���ɂ��Ɍ���
		if (m_uiCompACnt <= 40)
		{
			m_uiCompACnt++;
		}
		else
		{
			if (m_uiSinNum < 90)
			{
				OCR0AL = cnui8SinCountTbl[1][m_uiSinNum];
				OCR0BL = cnui8SinCountTbl[1][m_uiSinNum];
				m_uiSinNum++;
			}
			
			if (m_uiSinNum >= 90)
			{
				m_uiSinDeg   = 0;				// Sin Degree
				m_uiSinNum   = 0;				// Sin Table Num
				m_uiSinSeq   = 2;				// cos wave
			}
			
			m_uiCompACnt = 0;
		}
		break;
		
		
		
	case 2:	// ������
		
		m_uiWaitBlink++;
		if (m_uiWaitBlink >= 10000)				// �T�b���炢
		{
			m_uiSinDeg    = 0;					// Sin Degree
			m_uiSinNum    = 90;					// Sin Table Num
			m_uiSinSeq    = 3;					// cos wave
			m_uiWaitBlink = 0;
		}
		
		break;
		
	case 3:	// �u�����N
		if (m_uiCompACnt <= 10)
		{
			m_uiCompACnt++;
		}
		else
		{
			if (m_uiSinDeg < 89)
			{
				m_uiSinDeg++;
				m_uiSinNum--;
				
				OCR0AL = cnui8SinCountTbl[2][m_uiSinNum];
				OCR0BL = cnui8SinCountTbl[2][m_uiSinNum];
			}
			else	// m_uiSinDeg > 90
			{
				if (m_uiSinDeg < 179)
				{
					m_uiSinDeg++;
					m_uiSinNum++;
				}
				else
				{
					m_uiSinDeg = 0;
					m_uiSinNum = 0;
				}
				
				OCR0AL = cnui8SinCountTbl[2][m_uiSinNum];
				OCR0BL = cnui8SinCountTbl[2][m_uiSinNum];
			}
			
			// next sequence
			if (m_uiSinDeg >= 179)
			{
				m_uiSinDeg   = 0;				// Sin Degree
				m_uiSinNum   = 0;				// Sin Table Num
				m_uiSinSeq   = 2;				// cos wave
			}
			m_uiCompACnt = 0;
		}
		break;
	}	// switch (m_uiSinSeq)
}


int main(void)
{
	//---------------------------------------------------------
	// set main clock
	CCP     = 0xD8;								// �V�O�l�`���v���e�N�g����
	CLKPSR  = 0x00;								// �N���b�N�X�P�[�� CLKPSR bit3-0: CLKPS3-0 = 0011b
//	PRR    |= _BV(PRADC);						// ADC�ȃG�l        PRADC  bit2  : PRADC = 1b
	
	
	//-----------------------------------------
	// set timerA (wave mode, clock dev)
	TCCR0A |= 0x01;								// TCCR0A (����A)
												//   bit1-0: 01b (8bit �ʑ��PWM����)
	TCCR0B |= 0x02;								// TCCR0B (����B)
												//  bit4-3: 00b (8bit �ʑ��PWM����)
												//  bit2-0: 100 (256����)
												//  bit2-0: 011 (64����)
												//  bit2-0: 010 (8����)
												//  bit2-0: 001 (1����)
	
	//-----------------------------------------
	// set timerA (compare much)
	TCCR0A |=  0xa0;							// TCCR0A (����A)
												//  bit7-6: 10b (����v: L, ����v: H)
												//  bit5-4: 10b (����v: L, ����v: H)
	
	//---------------------------------------------------------
	// Port Settings
//	DDRB |= _BV(DDB0);							// PB0 output
//	DDRB |= _BV(DDB1);							// PB1 output
	DDRB  = 0x03;
	//	PUEB |= 0xFE;								// ���̓|�[�g������R�v���A�b�v�B(pull-up�́A���؃j�L�ɉ�H�ł���Ă��낽)
	
	// check counter over flow
	do
	{
		if (_BV(TOV0) & TIFR0)					// TIFR0(bit0):TOV0 == 1 ?
		{
			TIFR0 |= _BV(TOV0);					// TIFR0(bit0):TOV0 = 1 (clear flag)
			break;
		}
	} while (1);
	
	//-----------------------------------------
	// set interrupt bits
	TIMSK0 |= _BV(OCIE0A);						// TIMSK0(bit1): OCIE0A �R���y�A�}�b�`�o��A��������
	TIFR0  |= _BV(OCF0A);						// OCF0A (but1): OCF0A  �R���y�A�}�b�`�o��A�����v��
	
	//-----------------------------------------
	// start PWM duty value
	OCR0AL = cnui8SinCountTbl[0][0];
	OCR0BL = cnui8SinCountTbl[0][0];
	
	sei();
	do
	{
	} while (1);
}

